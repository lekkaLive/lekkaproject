<?php
    $szam = 2;
    kiir();

    function kiir()
    {
        global $szam;
        $lokalis_szam = 4;        
        echo $lokalis_szam;
        echo "<br>";
        echo $szam;
    }

    echo "<br>";
    echo $lokalis_szam;

?>