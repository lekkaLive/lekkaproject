<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lejart jelszó</title>
</head>
<body>
    Az ön jelszava lejárt!<br>
    Forduljon a rendszergazdához.<br>
    <br>
    <a href="../index.html">Vissza a belépés oldalra</a>
</body>
</html>